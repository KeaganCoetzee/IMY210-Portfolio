#ifndef LISTNODE_CPP
#define LISTNODE_CPP

#include <iostream>
#include <cmath>

template<class T>
ListNode<T>::ListNode(T val){
    this->value = val;
    this->prev = NULL;
    this->next = NULL;
}

template<class T>
ListNode<T>::~ListNode(){
   
    if(next!=NULL){
        next->prev = NULL;
        delete next;
        next = NULL;
    }

    if(prev !=NULL){
        prev->next = NULL;
        delete prev;
        prev = NULL;
    }
}


template<class T>
T ListNode<T>::getValue() const{
    return this->value;
}

template<class T>
int ListNode<T>::size() const{

    const ListNode<T>* head = this;
    while(head->prev != NULL){
        head = head->prev;
    }

    int count = 0;
    const ListNode<T>* current = head;
    while(current != NULL){
        current = current->next;
        count++;
    }

    return count;
}

template<class T>
void ListNode<T>::append(ListNode<T>* node){
    
    if(node == this || node == NULL){
        return;
    }

    ListNode<T>* head = this;
    while(head->prev != NULL){
        head = head->prev;
    }

    ListNode<T>* current = head;
    while(current != NULL){
        if(current == node){
            return;
        }
        current = current->next;
    }

    ListNode<T>* tail = head;
    while(tail->next != NULL){
        tail = tail->next;
    }

    tail->next = node;
    node->prev = tail;
    node->next = NULL;
}

template<class T>
void ListNode<T>::prepend(ListNode<T>* node){
    if(node == this || node == NULL){
        return;
    }

    ListNode<T>* head = this;
    while(head->prev != NULL){
        head = head->prev;
    }

    ListNode<T>* current = head;
    while(current!=NULL){
        if(current == node){
            return;
        }
        current = current->next;
    }

    ListNode<T>* begin = head;
    while(begin->prev!=NULL){
        begin = begin->prev;
    }

    begin->prev = node;
    node->prev = NULL;
    node->next = begin;

}

template<class T>
ListNode<T>* ListNode<T>::remove(ListNode<T>* node){
    if (node == NULL) {
        return NULL; 
    }

    if (node->prev != NULL) {
        (node->prev)->next = node->next;
    }
    if (node->next != NULL) {
        (node->next)->prev = node->prev;
    }

    node->prev = NULL;
    node->next = NULL;

    return node;
}

template<class T>
ListNode<T>* ListNode<T>::remove(int pos){

    if(pos == 0){
        return NULL;
    }

    if(std::abs(pos)>=size()) return NULL;

    ListNode<T>* head = this;

    if(pos<0){
        for(int i = 0; i<(-pos); i++){
            /*if(head->prev == NULL){
                return NULL;
            }*/
            head = head->prev;
        }
    }

    if(pos>0){
        for(int i = 0; i<pos; i++){
            /*if(head->next == NULL){
                return NULL;
            }*/
            head = head->next;
        }
    }

    if (head == NULL) {
        return NULL; 
    }

    if (head->prev != NULL) {
        (head->prev)->next = head->next;
    }
    if (head->next != NULL) {
        (head->next)->prev = head->prev;
    }

    head->prev = NULL;
    head->next = NULL;

    return head;
}


template<class T>
ListNode<T>* ListNode<T>::getNodeAt(int pos){


    ListNode<T>* head = this;

    if(pos == 0){
        return this;
    }

    if(std::abs(pos)>=size()) return NULL;
    
    if(pos<0){
        for(int i = 0; i<(-pos); i++){
            /*if(head->prev == NULL){
                return NULL;
            }*/
            head = head->prev;
        }

        return head;
    }

    if(pos>0){
        for(int i = 0; i<pos; i++){
            /*if(head->next == NULL){
                return NULL;
            }*/
            head = head->next;
        }

        return head;
    }

    return NULL;

}

template<class T>
void ListNode<T>::reverseList(){

    ListNode<T>* current = this;
    while (current->prev != NULL) {
        current = current->prev;
    }

    while (current != NULL) {
        ListNode<T>* temp = current->next;
        current->next = current->prev;
        current->prev = temp;

        current = temp;
    }

}

template<class T>
void ListNode<T>::printList() const{
const ListNode<T>* current = this;

    while (current->prev != NULL) {
        current = current->prev;
    }

    bool first = true;
    while (current != NULL) {
        if (!first) {
            std::cout << " ";
        }
        std::cout << current->value; 
        first = false;
        current = current->next;
    }
}







#endif //LISTNODE_CPP