#include <iostream>
#include "ListNode.h"

int main() {
    ListNode<int>* node1 = new ListNode<int>(10);
    ListNode<int>* node2 = new ListNode<int>(20);
    ListNode<int>* node3 = new ListNode<int>(30);

    node1->append(node2);
    node1->append(node3);

    std::cout << "List after append (should be 10 20 30): ";
    node1->printList();
    std::cout << std::endl;

    ListNode<int>* node0 = new ListNode<int>(5);
    node1->prepend(node0);

    std::cout << "List after prepend (should be 5 10 20 30): ";
    node1->printList();
    std::cout << std::endl;

    std::cout << "Number of nodes: " << node1->size() << std::endl;

    ListNode<int>* nodeAt2 = node1->getNodeAt(2);
    if (nodeAt2 != NULL) {
        std::cout << "Node 2 steps right of node1: " << nodeAt2->getValue() << std::endl;
    }

    ListNode<int>* removed = node1->remove(1);
    if (removed != NULL) {
        std::cout << "Removed node value: " << removed->getValue() << std::endl;
        delete removed;
    }

    std::cout << "List after removal (should be 5 10 30): ";
    node1->printList();
    std::cout << std::endl;

    ListNode<int>* removed2 = ListNode<int>::remove(node0);
    if (removed2 != NULL) {
        std::cout << "Removed node value: " << removed2->getValue() << std::endl;
        delete removed2;
    }

    std::cout << "List after second removal (should be 10 30): ";
    node1->printList();
    std::cout << std::endl;

    node1->reverseList();
    std::cout << "List after reverse (should be 30 10): ";
    node1->printList();
    std::cout << std::endl;

    delete node1; 
    node1 = NULL;

    return 0;
}
