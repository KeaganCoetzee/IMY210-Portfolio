import java.util.Scanner;
import java.util.ArrayList;

public class Main{
   public static void main(String[] args){

    Scanner input = new Scanner(System.in);

    ArrayList<String> tasks = new ArrayList<>();
    System.out.println("Type 'done' when you are finished.\n");

    while(true){
        System.out.println("Enter task: ");
        String task = input.nextLine();

        if(task.equalsIgnoreCase("done")){
            break;
        }
        tasks.add(task);
    }

    System.out.println("\n"+"Tasks");
    System.out.println("------------------");
    for(int i = 0; i<tasks.size();i++){
        
        System.out.println((i+1)+")"+tasks.get(i));
    }
   }
}